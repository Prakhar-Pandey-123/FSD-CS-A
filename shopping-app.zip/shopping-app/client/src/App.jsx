import React from "react";
import {BrowserRouter} from "react-router-dom"
import { Route,Routes } from "react-router-dom";
import Home from "./components/Home";
import UserDashboard from "./pages/UserDashboard";
import Cart from "./components/Cart"

const App=()=>{
  return(
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<UserDashboard></UserDashboard>}></Route>
      <Route path="/cart" element={<Cart></Cart>}></Route>

      <Route path="/cart" element={Cart}></Route>
      <Route path="/cart" element={}></Route>
      <Route path="/cart" element={}></Route>
      
    </Routes>

    </BrowserRouter>

  )

}
export default App