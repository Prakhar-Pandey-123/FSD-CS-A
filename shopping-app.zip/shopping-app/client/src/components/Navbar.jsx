import React from "react";
import "./Navbar.css"
import { Link } from "react-router";

const Navbar=()=>{
    return(
        <div> 
            <div> Navbar</div>
            <Link to="/cart" className="link-style">Cart</Link>
            <Link to="/orders" className="link-style">View Orders</Link>
            <Link to="/home" className="link-style">Home</Link>
            <Link to="/logout" className="link-style">logout</Link>
        </div>
    )
}
export default Navbar